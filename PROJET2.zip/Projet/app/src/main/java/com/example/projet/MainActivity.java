package com.example.projet;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Handler;
import android.os.ParcelUuid;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;


public class MainActivity extends AppCompatActivity {

    BluetoothAdapter bluetoothAdapter;
    String dataS= "";
    List<String> list = new ArrayList<String>();


    BluetoothDevice[] listeAppareil = new BluetoothDevice[20];//Contient tous les appreils detectés


    BluetoothDevice appareilSelect;    //Recupert l'appreil choisi pour se connecter


    BluetoothSocket socket;   //Bluetooth echange

    OutputStream    outputStream;

    Thread transmet;
    byte[] data = new byte[2];

    public Handler handler = new Handler();

    private AtomicBoolean ThreadAlive = new AtomicBoolean();



    Byte BLK_1      = (byte) 0x00;
    Byte BLK_2      = (byte) 0x20;

    Byte DO_1       = (byte) 0x01;
    Byte RE_1       = (byte) 0x02;
    Byte MI_1       = (byte) 0x04;
    Byte FA_1       = (byte) 0x08;
    Byte SOL_1      = (byte) 0x10;
    Byte LA_1       = (byte) 0x20;
    Byte SI_1       = (byte) 0x40;
    Byte DO_2       = (byte) 0x80;
    Byte DO_S_1     = (byte) 0x01;
    Byte RE_S_1     = (byte) 0x02;
    Byte FA_S_1     = (byte) 0x04;
    Byte SOL_S_1    = (byte) 0x08;
    Byte LA_S_1     = (byte) 0x10;


    String      appareilName;
    TextView    capteur;
    Spinner     listAppareil;
    Button      connect;

    Button      do_1;
    Button      re_1;
    Button      mi_1;
    Button      fa_1;
    Button      sol_1;
    Button      la_1;
    Button      si_1;
    Button      do_2;
    Button      do_s_1;
    Button      re_s_1;
    Button      fa_s_1;
    Button      sol_s_1;
    Button      la_s_1;



    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        do_1        = findViewById(R.id.btn_Do_1);
        re_1        = findViewById(R.id.btn_Re_1);
        mi_1        = findViewById(R.id.btn_Mi_1);
        fa_1        = findViewById(R.id.btn_Fa_1);
        sol_1       = findViewById(R.id.btn_Sol_1);
        la_1        = findViewById(R.id.btn_La_1);
        si_1        = findViewById(R.id.btn_Si_1);
        do_2        = findViewById(R.id.btn_Do_2);
        do_s_1      = findViewById(R.id.btn_Do_S_1);
        re_s_1      = findViewById(R.id.btn_Re_S_1);
        fa_s_1      = findViewById(R.id.btn_Fa_S_1);
        sol_s_1     = findViewById(R.id.btn_Sol_S_1);
        la_s_1      = findViewById(R.id.btn_La_S_1);

        connect      =  findViewById(R.id.btnConnexion);
        capteur      =  findViewById(R.id.txtCapteur);
        listAppareil =  findViewById(R.id.AppareilBluetooth);

        ImageButton pageInfo = findViewById(R.id.iBtnInfo);
        Button demo     = findViewById(R.id.btnDemo);





        connect     .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {procedureConnexion();
            }
        });

        listAppareil.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                appareilSelect = bluetoothAdapter.getRemoteDevice(listeAppareil[position].toString());
                appareilName   = list.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });

        ActivationBluetooth();

        pageInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, infoActivity.class);
                startActivity(intent);
            }
        });

        //selection des valeurs a envoyer
        do_1    .setOnTouchListener(sound_do_1);
        re_1    .setOnTouchListener(sound_re_1);
        mi_1    .setOnTouchListener(sound_mi_1);
        fa_1    .setOnTouchListener(sound_fa_1);
        sol_1   .setOnTouchListener(sound_sol_1);
        la_1    .setOnTouchListener(sound_la_1);
        si_1    .setOnTouchListener(sound_si_1);
        do_2    .setOnTouchListener(sound_do_2);
        do_s_1  .setOnTouchListener(sound_do_s_1);
        re_s_1  .setOnTouchListener(sound_re_s_1);
        fa_s_1  .setOnTouchListener(sound_fa_s_1);
        sol_s_1 .setOnTouchListener(sound_sol_s_1);
        la_s_1  .setOnTouchListener(sound_la_s_1);

        demo.setOnClickListener(demoS);

    }



    void procedureConnexion(){
        if(connect.getText().equals("Connexion") == true)
        {
            Toast.makeText(MainActivity.this, "Connection en cours",
                    Toast.LENGTH_SHORT).show();
            OpenConnection();
            connect.setText("Déconnexion");
        }
        else if (connect.getText().equals("Déconnexion") == true)
        {
            connect.setText("Connexion");
            Deconnection();
        }
    }

    private final static int REQUEST_CODE_ENABLE_BLUETOOTH = 0;
    void ActivationBluetooth()
    {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();




        if (bluetoothAdapter == null) {
            Toast.makeText(MainActivity.this, "L'appareil ne possède pas de bluetooth",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(MainActivity.this, "L'appareil possède du Bluetooth",
                    Toast.LENGTH_SHORT).show();
        }// vérifie si l'appareil possède ou non un module Bluetooth



        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBlueTooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBlueTooth, REQUEST_CODE_ENABLE_BLUETOOTH);
        } // propose à l'utilisateur d'activer le Bluetooth si il est désactivé




        int i = 0;
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if(pairedDevices.size() > 0)
        {
            for(BluetoothDevice device : pairedDevices)
            {
                list.add(device.getName());
                listeAppareil[i] = device;
                i++;
            }
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listAppareil.setAdapter(dataAdapter);

        appareilSelect = listeAppareil[0];
    }  //Recupère la liste des appareils visibles


    void Deconnection()
    {

        capteur.setText("Déconnecté");
        Toast.makeText(MainActivity.this, "Déconnexion",
                Toast.LENGTH_SHORT).show();
        try {
            ThreadAlive.set(false);
            socket.close();
        }catch (IOException e){}

    }  // Déconnecte l'appareil


    void OpenConnection()
    {
        data[0]=(byte)0x00;
        data[1]=(byte)0xA0;
        ParcelUuid[] uuid = appareilSelect.getUuids();
        Log.e("ID", appareilSelect.toString());
        try
        {
            socket = appareilSelect.createRfcommSocketToServiceRecord(uuid[0].getUuid());
            socket.connect();
            outputStream = socket.getOutputStream();

            String name = String.format("Connecté a %s", appareilName);
            capteur.setText(name);

            Toast.makeText(MainActivity.this, "Connexion",
                    Toast.LENGTH_SHORT).show();


            //initialise le Thread
            EmissionData();

            //Lance le thread
            ThreadAlive.set(true);
        }
        catch (IOException e)
        {

            capteur.setText("Connexion erreur");

            Toast.makeText(MainActivity.this, "Erreur connexion",
                    Toast.LENGTH_SHORT).show();

            ThreadAlive.set(false);

        }


    }// Tente d'établir un connection


    void EmissionData()
    {
        transmet = new Thread(new Runnable(){
            public void run()
            {
                while (ThreadAlive.get() == true)
                {

                }
            }
        });
        transmet.start();
    }  //émission des données

    void writeData()
    {
        if (ThreadAlive.get() == true) {
            try {
                dataS ="";
                outputStream.write(data);
                dataS = dataS + data [0];
                dataS = dataS +" "+ data [1];
                Log.i("Note",dataS);
            } catch (IOException e) {}
        }
    }

    protected void onDestroy()
    {
        super.onDestroy();

        ThreadAlive.set(false);

        try
        {
            transmet.join(100);
        } catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }
    void dDemo( Byte note_1,  Byte note_2, int time){
        handler.postDelayed(new Runnable() {
            public void run() {
                data[0]= note_1;
                data[1]= note_2;
                writeData();
            }

        }, time);
    }
    void demo1(){

        int temps = 0 ;
        dDemo(DO_1  , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(BLK_1 , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(DO_1  , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(BLK_1 , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(DO_1  , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(BLK_1 , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(RE_1  , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(BLK_1 , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(MI_1  , BLK_2 ,temps);
        temps = temps + 400;
        dDemo(BLK_1 , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(RE_1  , BLK_2 ,temps);
        temps = temps + 400;
        dDemo(BLK_1 , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(DO_1  , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(BLK_1 , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(MI_1  , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(BLK_1 , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(RE_1  , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(BLK_1 , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(RE_1  , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(BLK_1 , BLK_2 ,temps);
        temps = temps + 200;
        dDemo(DO_1  , BLK_2 ,temps);
        temps = temps + 800;
        dDemo(BLK_1 , BLK_2 ,temps);

    }


    final View.OnTouchListener sound_do_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= DO_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_re_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= RE_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_mi_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= MI_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_fa_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= FA_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_sol_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= SOL_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_la_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= LA_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_si_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= SI_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_do_2 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= DO_2;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_do_s_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= DO_S_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_re_s_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= RE_S_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_fa_s_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= FA_S_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_sol_s_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= SOL_S_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_la_s_1 = new View.OnTouchListener() {
        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= LA_S_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnClickListener demoS = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
           demo1();
            }
    };
}
