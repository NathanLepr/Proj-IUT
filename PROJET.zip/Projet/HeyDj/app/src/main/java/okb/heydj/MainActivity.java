package okb.heydj;

/*************************************************************************************************
 *                                      Projet Musical                                           *
 *                                          Hey DJ                                               *
 *                                      Version n°2.0 FINAL                                      *
 *                                        22/06/2018                                             *
 *                                                                                               *
 *  Projet de synthèse musical réalisé dans le cadre de la licence professionnel MECSE           *
 *                                                                                               *
 *                                                                                               *
 *                                                                                               *
 *  Ce projet est réalisé par "LES DJ KAWOT" composé de :                                        *
 *          Antoine MENET - Furkan MIRCILOGLU - Théophile MERLAND - Ulrich URSO                  *
 *                                                                                               *
 *                                                                                               *
 ************************************************************************************************/



import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.ParcelUuid;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;


public class MainActivity extends AppCompatActivity {

    BluetoothAdapter bluetoothAdapter;


    List<String> list = new ArrayList<String>();

    //Contient tous les appreils detectés
    BluetoothDevice[] listeAppareil = new BluetoothDevice[20];

    //Recupert l'appreil choisi pour se connecter
    BluetoothDevice appareilSelect;

    //Bluetooth echange
    BluetoothSocket socket;

    OutputStream    outputStream;

    Thread transmet;
    byte[] data = new byte[2];

    final Handler handler = new Handler();

    private AtomicBoolean ThreadAlive = new AtomicBoolean();




    Byte BLK_1      = (byte) 0x00;
    Byte BLK_2      = (byte) 0x80;

    Byte DO_1       = (byte) 0x01;
    Byte RE_1       = (byte) 0x02;
    Byte MI_1       = (byte) 0x04;
    Byte FA_1       = (byte) 0x08;
    Byte SOL_1      = (byte) 0x10;
    Byte LA_1       = (byte) 0x20;
    Byte SI_1       = (byte) 0x40;
    Byte DO_S_1     = (byte) 0x81;
    Byte RE_S_1     = (byte) 0x82;
    Byte FA_S_1     = (byte) 0x84;
    Byte SOL_S_1    = (byte) 0x88;
    Byte LA_S_1     = (byte) 0x90;
    Byte DO_2       = (byte) 0xA0;

    String      appareilName;
    int         selectedDemo;

    TextView    capteur;
    Spinner     listAppareil;
    Button      connect;

    Button      do_1;
    Button      re_1;
    Button      mi_1;
    Button      fa_1;
    Button      sol_1;
    Button      la_1;
    Button      si_1;
    Button      do_2;
    Button      do_s_1;
    Button      re_s_1;
    Button      fa_s_1;
    Button      sol_s_1;
    Button      la_s_1;



    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        do_1        = findViewById(R.id.btn_Do_1);
        re_1        = findViewById(R.id.btn_Re_1);
        mi_1        = findViewById(R.id.btn_Mi_1);
        fa_1        = findViewById(R.id.btn_Fa_1);
        sol_1       = findViewById(R.id.btn_Sol_1);
        la_1        = findViewById(R.id.btn_La_1);
        si_1        = findViewById(R.id.btn_Si_1);
        do_2        = findViewById(R.id.btn_Do_2);
        do_s_1      = findViewById(R.id.btn_Do_S_1);
        re_s_1      = findViewById(R.id.btn_Re_S_1);
        fa_s_1      = findViewById(R.id.btn_Fa_S_1);
        sol_s_1     = findViewById(R.id.btn_Sol_S_1);
        la_s_1      = findViewById(R.id.btn_La_S_1);

        connect      =  findViewById(R.id.btnConnexion);
        capteur      =  findViewById(R.id.txtCapteur);
        listAppareil =  findViewById(R.id.ListeAppareilBluetooth);

        ImageButton pageInfo = findViewById(R.id.iBtnInfo);
        Spinner listDemo     = findViewById(R.id.spinDemo);
        Button musicdemo     = findViewById(R.id.btnDemo);
        Button musicLearn    = findViewById(R.id.btnLearn);



        //----------------------------------------------------------------------------------------*/
        connect     .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {procedureConnexion();
            }
        });
        //----------------------------------------------------------------------------------------*/
        listAppareil.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                appareilSelect = bluetoothAdapter.getRemoteDevice(listeAppareil[position].toString());
                appareilName   = list.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });
        //----------------------------------------------------------------------------------------*/
        ActivationBluetooth();
        //----------------------------------------------------------------------------------------*/
        pageInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, infoActivity.class);
                startActivity(intent);
            }
        });
        //----------------------------------------------------------------------------------------*/
        //selection des valeurs a envoyer
        do_1    .setOnTouchListener(sound_do_1);
        re_1    .setOnTouchListener(sound_re_1);
        mi_1    .setOnTouchListener(sound_mi_1);
        fa_1    .setOnTouchListener(sound_fa_1);
        sol_1   .setOnTouchListener(sound_sol_1);
        la_1    .setOnTouchListener(sound_la_1);
        si_1    .setOnTouchListener(sound_si_1);
        do_2    .setOnTouchListener(sound_do_2);
        do_s_1  .setOnTouchListener(sound_do_s_1);
        re_s_1  .setOnTouchListener(sound_re_s_1);
        fa_s_1  .setOnTouchListener(sound_fa_s_1);
        sol_s_1 .setOnTouchListener(sound_sol_s_1);
        la_s_1  .setOnTouchListener(sound_la_s_1);


        musicdemo    .setOnClickListener(demoSwitch);
        musicLearn   .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                learn();
            }
        });
        //----------------------------------------------------------------------------------------*/
        //Spinner et info le contenant
        List DemoListA = new ArrayList();
        DemoListA.add("Au clair de la lune");
        DemoListA.add("Heart and Soul");
        DemoListA.add("Les petits poissons");

        final ArrayAdapter adapterDemo = new ArrayAdapter(this,
                        R.layout.support_simple_spinner_dropdown_item, DemoListA);
        listDemo .setAdapter(adapterDemo);
        listDemo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedDemo = i;
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //----------------------------------------------------------------------------------------*/
    }
    //=========================================================================================*/
    //=========================================================================================*/
    //=========================================================================================*/
    void demo1(){
        // Do Do Do Re Mi Re Do Mi Re Re Do
        int temps = 0 ;
        delayDemo(DO_1  , BLK_2 ,temps); //DO
        temps=temps+200;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
        temps=temps+200;
        delayDemo(DO_1  , BLK_2 ,temps); //DO
        temps=temps+200;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
        temps=temps+200;
        delayDemo(DO_1  , BLK_2 ,temps); //DO
        temps=temps+200;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
        temps=temps+200;
        delayDemo(RE_1  , BLK_2 ,temps); //RE
        temps=temps+200;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
        temps=temps+200;
        delayDemo(MI_1  , BLK_2 ,temps); //MI
        temps=temps+500;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
        temps=temps+200;
        delayDemo(RE_1  , BLK_2 ,temps); //RE
        temps=temps+500;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
        temps=temps+200;
        delayDemo(DO_1  , BLK_2 ,temps); //DO
        temps=temps+200;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
        temps=temps+200;
        delayDemo(MI_1  , BLK_2 ,temps); //MI
        temps=temps+200;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
        temps=temps+200;
        delayDemo(RE_1  , BLK_2 ,temps); //RE
        temps=temps+200;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
        temps=temps+200;
        delayDemo(RE_1  , BLK_2 ,temps); //RE
        temps=temps+200;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
        temps=temps+200;
        delayDemo(DO_1  , BLK_2 ,temps); //DO
        temps=temps+500;
        delayDemo(BLK_1 , BLK_2 ,temps); //vide
    }
    //----------------------------------------------------------------------------------------*/
    void demo2() {
        // FA FA LA LA RE RE FA FA SOL SOL  LA# LA# DO DO MI MI
        int temps = 0;
        delayDemo(FA_1  , BLK_2 ,temps); //FA
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(FA_1  , BLK_2 ,temps); //FA
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(LA_1  , BLK_2 ,temps); //LA
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(LA_1  , BLK_2 ,temps); //LA
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(RE_1  , BLK_2 ,temps); //RE
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(RE_1  , BLK_2 ,temps); //RE
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(FA_1  , BLK_2 ,temps); //FA
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(FA_1  , BLK_2 ,temps); //FA
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(SOL_1  , BLK_2 ,temps); //SOL
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(SOL_1  , BLK_2 ,temps); //SOL
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(BLK_1  , LA_S_1 ,temps); //LA#
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(BLK_1  , LA_S_1 ,temps); //LA#
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(DO_1  , BLK_2 ,temps); //DO
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(DO_1  , BLK_2 ,temps); //DO
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(MI_1  , BLK_2 ,temps); //MI
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(MI_1  , BLK_2 ,temps); //MI
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
    }
    //----------------------------------------------------------------------------------------*/
    void demo3() {
        // RE MI FA SOL LA LA# LA SOL SOL FA FA MI FA SOL LA FA RE
        int temps = 0;
        delayDemo(RE_1  , BLK_2 ,temps); //RE
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(MI_1  , BLK_2 ,temps); //MI
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(FA_1  , BLK_2 ,temps); //FA
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(SOL_1  , BLK_2 ,temps); //SOL
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(LA_1  , BLK_2 ,temps); //LA
        temps=temps+400;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+400;
        delayDemo(BLK_1  , LA_S_1 ,temps); //LA#
        temps=temps+400;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+400;
        delayDemo(LA_1  , BLK_2 ,temps); //LA
        temps=temps+400;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+200;
        delayDemo(SOL_1  , BLK_2 ,temps); //SOL
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+200;
        delayDemo(SOL_1  , BLK_2 ,temps); //SOL
        temps=temps+300;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+200;
        delayDemo(FA_1  , BLK_2 ,temps); //FA
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+200;
        delayDemo(FA_1  , BLK_2 ,temps); //FA
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+300;
        delayDemo(MI_1  , BLK_2 ,temps); //MI
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(FA_1  , BLK_2 ,temps); //FA
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(SOL_1  , BLK_2 ,temps); //SOL
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+100;
        delayDemo(LA_1  , BLK_2 ,temps); //LA
        temps=temps+100;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+200;
        delayDemo(FA_1  , BLK_2 ,temps); //FA
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);
        temps=temps+200;
        delayDemo(RE_1  , BLK_2 ,temps); //RA
        temps=temps+200;
        delayDemo(BLK_1  , BLK_2 ,temps);


    }
    //----------------------------------------------------------------------------------------*/
    void learn(){
        // Do Do Do Re Mi Re Do Mi Re Re Do

        delayLearn(do_1, "BLUE"  ,1000); //DO
        delayLearn(do_1, "WHITE" ,1500);

        delayLearn(do_1, "BLUE"  ,2000); //DO
        delayLearn(do_1, "WHITE" ,2500);

        delayLearn(do_1, "BLUE"  ,3000); //DO
        delayLearn(do_1, "WHITE" ,3500);

        delayLearn(re_1, "BLUE"  ,4000); //RE
        delayLearn(re_1, "GRAY"  ,4500);

        delayLearn(mi_1, "BLUE"  ,5000); //MI
        delayLearn(mi_1, "WHITE" ,6000);

        delayLearn(re_1, "BLUE"  ,6500); //RE
        delayLearn(re_1, "GRAY"  ,7500);

        delayLearn(do_1, "BLUE"  ,8000); //DO
        delayLearn(do_1, "WHITE" ,8500);

        delayLearn(mi_1, "BLUE"  ,9000); //MI
        delayLearn(mi_1, "WHITE" ,9500);

        delayLearn(re_1, "BLUE"  ,10000); //RE
        delayLearn(re_1, "GRAY"  ,10500);

        delayLearn(re_1, "BLUE"  ,11000); //RE
        delayLearn(re_1, "GRAY"  ,11500);

        delayLearn(do_1, "BLUE"  ,12000); //DO
        delayLearn(do_1, "WHITE" ,12500);


    }
    //----------------------------------------------------------------------------------------*/
    void delayDemo(final Byte note_1, final Byte note_2, int time){
        handler.postDelayed(new Runnable() {
            public void run() {
                data[0]= note_1;
                data[1]= note_2;
                writeData();
            }

        }, time);
    }
    //----------------------------------------------------------------------------------------*/
    void delayLearn(final Button btn, final String color, int time){
        handler.postDelayed(new Runnable() {
            public void run() {
                // wait 1s
                if(color == "BLUE"){
                    btn.setBackgroundColor(Color.BLUE);}
                if(color == "WHITE"){
                    btn.setBackgroundColor(Color.LTGRAY);}
                else if(color == "GRAY"){
                    btn.setBackgroundColor(Color.parseColor("#b0b0b0"));}
            }
        }, time);
    }
    //=========================================================================================/
    //=========================================================================================/
    //=========================================================================================/
    void procedureConnexion(){
        if(connect.getText().equals("CONNEXION") == true)
        {
            Toast.makeText(MainActivity.this, "Connection en cours",
                    Toast.LENGTH_SHORT).show();
            OpenConnection();
            connect.setText("DECONNEXION");
        }
        else if (connect.getText().equals("DECONNEXION") == true)
        {
            connect.setText("CONNEXION");
            Deconnection();
        }
    }
    //----------------------------------------------------------------------------------------*/
    private final static int REQUEST_CODE_ENABLE_BLUETOOTH = 0;
    void ActivationBluetooth()
      {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        //----------------------------------------------------------------------------------------*/
        // vérifie si l'appareil possède ou non un module Bluetooth

        if (bluetoothAdapter == null) {
            Toast.makeText(MainActivity.this, "L'appareil ne possède pas de bluetooth",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(MainActivity.this, "L'appareil possède du Bluetooth",
                    Toast.LENGTH_SHORT).show();
        }
        //----------------------------------------------------------------------------------------*/
        // propose à l'utilisateur d'activé le Bluetooth si il est désactivé

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBlueTooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBlueTooth, REQUEST_CODE_ENABLE_BLUETOOTH);
        }//*/
        // Permet d'activé le Bluetooth sans demander l'avis de l'utilisateur
        /*
        if (!bluetoothAdapter.isEnabled()) {
            bluetoothAdapter.enable();
        }


        //----------------------------------------------------------------------------------------*/
        //Recupere la liste des appareils visibles
        int i = 0;
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if(pairedDevices.size() > 0)
        {
            for(BluetoothDevice device : pairedDevices)
            {
                list.add(device.getName());
                listeAppareil[i] = device;
                i++;
            }
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listAppareil.setAdapter(dataAdapter);

        appareilSelect = listeAppareil[0];
    }
    //----------------------------------------------------------------------------------------*/
    // Déconnecte l'appareil
    void Deconnection()
    {

        capteur.setText("Décoonnecter");
        Toast.makeText(MainActivity.this, "Deconnection",
                Toast.LENGTH_SHORT).show();
        try {
            ThreadAlive.set(false);
            socket.close();
        }catch (IOException e){}

    }
    //----------------------------------------------------------------------------------------*/
    // Tente d'établir un connection
    void OpenConnection()
    {
        data[0]=(byte)0x00;
        data[1]=(byte)0x80;
        ParcelUuid[] uuid = appareilSelect.getUuids();
        Log.e("ID", appareilSelect.toString());
        try
        {
            socket = appareilSelect.createRfcommSocketToServiceRecord(uuid[0].getUuid());
            socket.connect();
            outputStream = socket.getOutputStream();

            String name = String.format("Connecter a %s", appareilName);
            capteur.setText(name);

            Toast.makeText(MainActivity.this, "Connection etablie",
                    Toast.LENGTH_SHORT).show();


            //initialise le Thread
            EmetData();

            //Lance le thread
            ThreadAlive.set(true);
        }
        catch (IOException e)
        {

            capteur.setText("Connection erreur");

            Toast.makeText(MainActivity.this, "Connection erreur",
                    Toast.LENGTH_SHORT).show();

            ThreadAlive.set(false);

        }


    }
    //----------------------------------------------------------------------------------------*/
    //emmet les données
    void EmetData()
    {
        transmet = new Thread(new Runnable(){
            public void run()
            {
                while (ThreadAlive.get() == true)
                {

                }
            }
        });
        transmet.start();
    }
    //----------------------------------------------------------------------------------------*/
    void writeData()
    {
        if (ThreadAlive.get() == true) {
        try {
            outputStream.write(data);
        } catch (IOException e) {}
        }
    }
    //----------------------------------------------------------------------------------------*/
    protected void onDestroy()
    {
        super.onDestroy();

        ThreadAlive.set(false);
        // trasmet.interrupt();
        try
        {
            transmet.join(100);
        } catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }
    //=========================================================================================/
    //=========================================================================================/
    //=========================================================================================/

    final View.OnTouchListener sound_do_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= DO_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_re_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= RE_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_mi_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= MI_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_fa_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= FA_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_sol_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= SOL_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_la_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= LA_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_si_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[0] |= SI_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_do_2 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= DO_2;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_do_s_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= DO_S_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_re_s_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= RE_S_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_fa_s_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= FA_S_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_sol_s_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= SOL_S_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };
    final View.OnTouchListener sound_la_s_1 = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {
            data[1] |= LA_S_1;
            if (event.getAction() == MotionEvent.ACTION_UP) {data[0]=BLK_1;data[1] =BLK_2;}
            writeData();
            return false;
        }
    };

    final View.OnClickListener demoSwitch = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (selectedDemo){
                case 0 :
                    demo1();
                    break;
                case 1 :
                    demo2();
                    break;
                case 2 :
                    demo3();
                    break;
            }
        }
    };


}
